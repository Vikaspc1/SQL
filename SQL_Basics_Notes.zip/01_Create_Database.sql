
-- Create Database
CREATE DATABASE company_db;
USE company_db;
