
-- JOINS
SELECT e.name, e.department, d.dept_name
FROM employees e
INNER JOIN departments d ON e.department = d.dept_name;

-- LEFT JOIN example
SELECT e.name, d.dept_name
FROM employees e
LEFT JOIN departments d ON e.department = d.dept_name;
