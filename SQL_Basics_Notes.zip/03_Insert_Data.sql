
-- Insert Data
INSERT INTO departments (dept_name) VALUES ('HR'), ('Finance'), ('IT'), ('Marketing');

INSERT INTO employees (name, age, department, salary) VALUES
('Alice', 25, 'IT', 50000),
('Bob', 30, 'Finance', 60000),
('Charlie', 28, 'HR', 45000),
('David', 35, 'Marketing', 70000),
('Eva', 29, 'IT', 52000);
