
# 📘 SQL Notes for Freshers (MySQL)

## 📌 Overview
This repository contains beginner-friendly SQL scripts covering the fundamentals required for freshers in interviews and projects.

## 📂 Contents
- 01_Create_Database.sql
- 02_Create_Tables.sql
- 03_Insert_Data.sql
- 04_Select_Queries.sql
- 05_Filtering_Conditions.sql
- 06_Aggregate_Functions.sql
- 07_Joins.sql
- 08_Subqueries.sql
- 09_Index_Views.sql
- Sample_Dataset.sql

## 🚀 How to Use
1. Install MySQL
2. Run `Sample_Dataset.sql` to create tables and sample data
3. Execute each script in order to learn SQL concepts step-by-step
