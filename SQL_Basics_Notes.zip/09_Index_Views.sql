
-- Create Index
CREATE INDEX idx_department ON employees(department);

-- Create View
CREATE VIEW high_salary_emps AS
SELECT name, salary FROM employees WHERE salary > 55000;
