
-- Basic SELECT queries
SELECT * FROM employees;
SELECT name, salary FROM employees;
SELECT * FROM employees WHERE department='IT';
