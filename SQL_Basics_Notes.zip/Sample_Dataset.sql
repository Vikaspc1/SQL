
-- Sample Dataset for Practice
DROP DATABASE IF EXISTS company_db;
CREATE DATABASE company_db;
USE company_db;

CREATE TABLE employees (
    emp_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50),
    age INT,
    department VARCHAR(50),
    salary DECIMAL(10,2)
);

CREATE TABLE departments (
    dept_id INT PRIMARY KEY AUTO_INCREMENT,
    dept_name VARCHAR(50)
);

INSERT INTO departments (dept_name) VALUES ('HR'), ('Finance'), ('IT'), ('Marketing');

INSERT INTO employees (name, age, department, salary) VALUES
('Alice', 25, 'IT', 50000),
('Bob', 30, 'Finance', 60000),
('Charlie', 28, 'HR', 45000),
('David', 35, 'Marketing', 70000),
('Eva', 29, 'IT', 52000);
