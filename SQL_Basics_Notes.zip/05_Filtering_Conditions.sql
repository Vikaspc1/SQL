
-- WHERE, ORDER BY, LIMIT
SELECT * FROM employees WHERE salary > 50000;
SELECT * FROM employees ORDER BY salary DESC;
SELECT * FROM employees LIMIT 3;
